const mongoose = require('mongoose')
const Schema = mongoose.Schema

// Create Schema
const UserSchema = new Schema({
  first_name: {
    type: String
  },
  last_name: {
    type: String
  },
  email: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  },
  date1: {
    type: String,
    required: true
  },
  description1: {
    type: String,
    required: true
  },
  amount1: {
    type: Number,
    required: true
  },
  date2: {
    type: String,
    required: true
  },
  description2: {
    type: String,
    required: true
  },
  amount2: {
    type: Number,
    required: true
  },
  balance: {
    type: Number,
    required: true
  },
  date: {
    type: Date,
    default: Date.now
  }
})

module.exports = User = mongoose.model('users', UserSchema)