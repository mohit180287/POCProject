import React, { Component } from 'react'
import jwt_decode from 'jwt-decode'
import { decode } from 'jsonwebtoken'

class Profile extends Component {
  constructor() {
    super()
    this.state = {
 //     first_name: '',
 //     last_name: '',
 //     email: '',
      date1: '',
      description1: '',
      amount1: '',
      date2: '',
      description2: '',
      amount2: '',
      balance: '',
    }
  }

  componentDidMount() {
    const token = localStorage.usertoken
    const decoded = jwt_decode(token)
    this.setState({
      first_name: decoded.first_name,
      last_name: decoded.last_name,
 //     email: decoded.email,
      date1: decoded.date1,
      description1: decoded.description1,
      amount1: decoded.amount1,
      date2: decoded.date2,
      description2: decoded.description2,
      amount2: decoded.amount2,
      balance: decoded.balance
    })
  }

  render() {
    return (
      <div  className="container">
        <div>
          <div>
            <h>Welcome </h>
            <h>{this.state.first_name }</h>
            <h> </h>
            <h>{this.state.last_name}</h>
            <h>!</h>
          </div>
          <div>
            <h>Account Balance:</h>
            <h>{this.state.balance}</h>
          </div>
          <table  className="table table-bordered">
            <tbody>
            <tr>
                <th>Date</th>
               <th>Description</th>
               <th>Amount</th>
            </tr>
            <tr>
            <td>{this.state.date1}</td> 
            <td>{this.state.description1}</td> 
            <td>{this.state.amount1}</td>  
            </tr>
            <tr>
            <td>{this.state.date2}</td> 
            <td>{this.state.description2}</td> 
            <td>{this.state.amount2}</td>  
            </tr>
            </tbody>
          </table>
        </div>
      </div>
    )
  }
}

export default Profile