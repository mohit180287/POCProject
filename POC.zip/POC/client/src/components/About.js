import React, { Component } from 'react'

class About extends Component {
  render() {
    return (
      <div>
          <h1> <u> About iJavaScript </u> </h1>
          <p1>ijavascript is research group, founded to check different javascript frameworks 
              based on different design pattern.
              During kick-off it will test React, Angular, knockout and Ember JS features. This 
              use case will prove different aspects of framework capabilities.</p1>
              <h1> <u> About React</u> </h1>
          <p1>React is an open-source frontend JavaScript library which is used for building user interfaces especially for single page applications. 
            It is used for handling view layer for web and mobile apps. React was created by Jordan Walke.</p1>
            <h1> <u> About NodeJs</u> </h1>
          <p1>Node.js is a platform built on Chrome's JavaScript runtime for easily building fast and scalable network applications. Node.js uses an event-driven, non-blocking I/O model that makes it lightweight and efficient, 
            perfect for data-intensive real-time applications that run across distributed devices.</p1>
      </div>      
    )
  }
}

export default About