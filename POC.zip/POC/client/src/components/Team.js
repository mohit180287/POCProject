import React, { Component } from "react";
class Team extends React.Component {
    state = {
      isLoading: true,
      users: [],
      error: null
    }
  
    render() {
        const { isLoading, users, error } = this.state;
        return (
          <React.Fragment>
            <h1>Meet The Team</h1>            
            {error ? <p>{error.message}</p> : null}            
            {!isLoading ? (
              users.map(user => {
                const {name} = user;
                return (
                  <div>
                    <p>{name}</p>
                    <hr />
                  </div>
                );
              })
            // If there is a delay in data, let's let the user know it's loading
            ) : (
              <h3>Loading...</h3>
            )}
          </React.Fragment>
        );
      }

      fetchUsers() {
        // Where we're fetching data from
        fetch(`https://jsonplaceholder.typicode.com/users`)
          // We get the API response and receive data in JSON format...
          .then(response => response.json())
          // ...then we update the users state
          .then(data =>
            this.setState({
              users: data,
              isLoading: false,
            })
          )
          // Catch any errors we hit and update the app
          .catch(error => this.setState({ error, isLoading: false }));
      }

      componentDidMount() {
        this.fetchUsers();
      }
    }
    export default Team
