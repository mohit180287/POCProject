import React, { Component } from 'react'
import { register } from './UserFunctions'

class Register extends Component {
  constructor() {
    super()
    this.state = {
      first_name: '',
      last_name: '',
      email: '',
      password: '',
      date1: '',
      description1: '',
      amount1: '',
      date2: '',
      description2: '',
      amount2: '',
      balance: '',
    }
    this.onChange = this.onChange.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
  }

  onChange(e) {
    this.setState({ [e.target.name]: e.target.value })
  }

  onSubmit(e) {
    e.preventDefault()

    const User = {
      first_name: this.state.first_name,
      last_name: this.state.last_name,
      email: this.state.email,
      password: this.state.password,
      date1: this.state.date1,
      description1: this.state.description1,
      amount1: this.state.amount1,
      date2: this.state.date2,
      description2: this.state.description2,
      amount2: this.state.amount2,
      balance: this.state.balance
          }

    register(User).then(res => {
      this.props.history.push(`/login`)
    })
  }

  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-6 mt-5 mx-auto">
            <form noValidate onSubmit={this.onSubmit}>
              <h1 className="h3 mb-3 font-weight-normal">Register</h1>
              <div className="form-group">
                <label htmlFor="name">First name</label>
                <input type="text"
                  className="form-control"
                  name="first_name"
                  placeholder="Enter First Name"
                  value={this.state.first_name}
                  onChange={this.onChange} />
              </div>
              <div className="form-group">
                <label htmlFor="name">Last name</label>
                <input type="text"
                  className="form-control"
                  name="last_name"
                  placeholder="Enter Lastname Name"
                  value={this.state.last_name}
                  onChange={this.onChange} />
              </div>
              <div className="form-group">
                <label htmlFor="email">Email address</label>
                <input type="email"
                  className="form-control"
                  name="email"
                  placeholder="Enter email"
                  value={this.state.email}
                  onChange={this.onChange} />
              </div>
              <div className="form-group">
                <label htmlFor="password">Password</label>
                <input type="password"
                  className="form-control"
                  name="password"
                  placeholder="Password"
                  value={this.state.password}
                  onChange={this.onChange} />
              </div>
                <div className="form-group">
                <label htmlFor="date1">Date1</label>
                <input type="date1"
                  className="form-control"
                  name="date1"
                  placeholder="date1"
                  value={this.state.date1}
                  onChange={this.onChange} />
              </div>
              <div className="form-group">
                <label htmlFor="description1">Description1</label>
                <input type="description1"
                  className="form-control"
                  name="description1"
                  placeholder="description1"
                  value={this.state.description1}
                  onChange={this.onChange} />
              </div>
              <div className="form-group">
                <label htmlFor="amount1">Amount1</label>
                <input type="amount1"
                  className="form-control"
                  name="amount1"
                  placeholder="amount1"
                  value={this.state.amount1}
                  onChange={this.onChange} />
              </div>
              <div className="form-group">
                <label htmlFor="date2">Date2</label>
                <input type="date2"
                  className="form-control"
                  name="date2"
                  placeholder="date2"
                  value={this.state.date2}
                  onChange={this.onChange} />
              </div>
              <div className="form-group">
                <label htmlFor="description2">Description2</label>
                <input type="description2"
                  className="form-control"
                  name="description2"
                  placeholder="description2"
                  value={this.state.description2}
                  onChange={this.onChange} />
              </div>
              <div className="form-group">
                <label htmlFor="amount2">Amount2</label>
                <input type="amount2"
                  className="form-control"
                  name="amount2"
                  placeholder="amount2"
                  value={this.state.amount2}
                  onChange={this.onChange} />
              </div>
              <div className="form-group">
                <label htmlFor="balance">Balance</label>
                <input type="balance"
                  className="form-control"
                  name="balance"
                  placeholder="balance"
                  value={this.state.balance}
                  onChange={this.onChange} />
              </div>
              <button type="submit" className="btn btn-lg btn-primary btn-block">
                Register
              </button>
            </form>
          </div>
        </div>
      </div>
    )
  }
}

export default Register