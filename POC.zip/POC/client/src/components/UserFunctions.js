import axios from 'axios'

export const register = newUser => {
  return axios
    .post('users/register', {
      first_name: newUser.first_name,
      last_name: newUser.last_name,
      email: newUser.email,
      password: newUser.password,
      date1: newUser.date1,
      description1: newUser.description1,
      amount1: newUser.amount1,
      date2: newUser.date2,
      description2: newUser.description2,
      amount2: newUser.amount2,
      balance: newUser.balance
    })
    .then(res => {
      console.log('Registered!')
    })
}

export const login = user => {
  return axios
    .post('users/login', {
      email: user.email,
      password: user.password
    })
    .then(res => {
      localStorage.setItem('usertoken', res.data)
      return res.data
    })
    .catch(err => {
      console.log(err)
    })
}

